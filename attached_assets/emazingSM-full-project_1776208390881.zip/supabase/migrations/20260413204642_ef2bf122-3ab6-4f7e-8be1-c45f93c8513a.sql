-- Recreate view with SECURITY INVOKER (respects caller's RLS)
CREATE OR REPLACE VIEW public.user_orders_safe
WITH (security_invoker = true) AS
SELECT
  id, user_id, service_id, external_order_id, link, quantity,
  start_count, remains, cost, status, created_at, updated_at
FROM public.orders;