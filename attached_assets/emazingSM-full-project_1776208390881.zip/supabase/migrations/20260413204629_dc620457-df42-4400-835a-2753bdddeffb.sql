-- Fix: Blog posts admin-only write policies
CREATE POLICY "Admins can insert blog posts"
ON public.blog_posts FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update blog posts"
ON public.blog_posts FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete blog posts"
ON public.blog_posts FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Fix: Create a safe view for user orders that hides internal financial data
CREATE OR REPLACE VIEW public.user_orders_safe AS
SELECT
  id, user_id, service_id, external_order_id, link, quantity,
  start_count, remains, cost, status, created_at, updated_at
FROM public.orders;

-- Grant access to the view
GRANT SELECT ON public.user_orders_safe TO authenticated;
GRANT SELECT ON public.user_orders_safe TO anon;