
-- Enable extensions for cron scheduling
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Function: auto-credit referral commission on order insert
CREATE OR REPLACE FUNCTION public.process_referral_commission()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  ref_record RECORD;
  commission_amount NUMERIC;
BEGIN
  -- Find if order user was referred by someone
  SELECT * INTO ref_record
  FROM public.referrals
  WHERE referred_id = NEW.user_id AND status = 'active'
  LIMIT 1;

  IF ref_record IS NULL THEN
    RETURN NEW;
  END IF;

  -- Calculate commission on order cost
  commission_amount := ROUND(NEW.cost * ref_record.commission_rate, 4);

  IF commission_amount <= 0 THEN
    RETURN NEW;
  END IF;

  -- Credit referrer's wallet
  UPDATE public.wallets
  SET balance = balance + commission_amount, updated_at = now()
  WHERE user_id = ref_record.referrer_id;

  -- Update referral total earnings
  UPDATE public.referrals
  SET total_earnings = total_earnings + commission_amount, updated_at = now()
  WHERE id = ref_record.id;

  -- Log the transaction
  INSERT INTO public.wallet_transactions (user_id, type, amount, description, status, payment_method, reference_id)
  VALUES (
    ref_record.referrer_id,
    'referral_commission',
    commission_amount,
    'Referral commission from order ' || NEW.id::text,
    'completed',
    'system',
    NEW.id::text
  );

  -- Notify the referrer
  INSERT INTO public.notifications (user_id, title, message, type, link)
  VALUES (
    ref_record.referrer_id,
    '💰 Referral Earning!',
    'You earned $' || commission_amount::text || ' commission from a referred user''s order.',
    'success',
    '/dashboard/affiliates'
  );

  RETURN NEW;
END;
$$;

-- Trigger: process referral on new order
CREATE TRIGGER trg_referral_commission
AFTER INSERT ON public.orders
FOR EACH ROW
EXECUTE FUNCTION public.process_referral_commission();

-- Function: check loyalty milestones after order
CREATE OR REPLACE FUNCTION public.check_loyalty_milestone()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  total_spent NUMERIC;
  milestone_key TEXT;
  bonus NUMERIC;
  already_awarded BOOLEAN;
  milestones JSONB := '[
    {"threshold": 100, "bonus": 2, "level": "Junior"},
    {"threshold": 500, "bonus": 10, "level": "Frequent"},
    {"threshold": 1000, "bonus": 25, "level": "Elite"},
    {"threshold": 2500, "bonus": 50, "level": "VIP"},
    {"threshold": 5000, "bonus": 100, "level": "Master"}
  ]'::jsonb;
  m JSONB;
BEGIN
  -- Calculate user's total spending
  SELECT COALESCE(SUM(cost), 0) INTO total_spent
  FROM public.orders
  WHERE user_id = NEW.user_id;

  -- Check each milestone
  FOR m IN SELECT * FROM jsonb_array_elements(milestones)
  LOOP
    IF total_spent >= (m->>'threshold')::numeric THEN
      milestone_key := 'loyalty_milestone_' || (m->>'threshold');

      -- Check if already awarded
      SELECT EXISTS(
        SELECT 1 FROM public.wallet_transactions
        WHERE user_id = NEW.user_id
          AND reference_id = milestone_key
          AND type = 'loyalty_bonus'
      ) INTO already_awarded;

      IF NOT already_awarded THEN
        bonus := (m->>'bonus')::numeric;

        -- Credit wallet
        UPDATE public.wallets
        SET balance = balance + bonus, updated_at = now()
        WHERE user_id = NEW.user_id;

        -- Log transaction
        INSERT INTO public.wallet_transactions (user_id, type, amount, description, status, payment_method, reference_id)
        VALUES (
          NEW.user_id,
          'loyalty_bonus',
          bonus,
          'Loyalty bonus for reaching ' || (m->>'level') || ' level ($' || (m->>'threshold') || ' spent)',
          'completed',
          'system',
          milestone_key
        );

        -- Notify user
        INSERT INTO public.notifications (user_id, title, message, type, link)
        VALUES (
          NEW.user_id,
          '🎉 Level Up: ' || (m->>'level') || '!',
          'Congratulations! You reached ' || (m->>'level') || ' level and earned a $' || bonus::text || ' bonus!',
          'success',
          '/dashboard'
        );
      END IF;
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$;

-- Trigger: check loyalty after new order
CREATE TRIGGER trg_loyalty_milestone
AFTER INSERT ON public.orders
FOR EACH ROW
EXECUTE FUNCTION public.check_loyalty_milestone();

-- Allow service role to insert wallet_transactions (for triggers)
CREATE POLICY "Service role can insert wallet_transactions"
ON public.wallet_transactions
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Allow service role to insert notifications (for triggers)
CREATE POLICY "Service role can insert notifications"
ON public.notifications
FOR INSERT
TO authenticated
WITH CHECK (true);
