-- Drop the permissive coupon SELECT policy that still exists
DROP POLICY IF EXISTS "Authenticated users can view active coupons" ON public.coupons;

-- Create validate_coupon secure function
CREATE OR REPLACE FUNCTION public.validate_coupon(_code text, _order_amount numeric)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  c RECORD;
  discount numeric;
BEGIN
  SELECT * INTO c FROM public.coupons
  WHERE code = _code AND is_active = true
  LIMIT 1;

  IF c IS NULL THEN
    RETURN jsonb_build_object('valid', false, 'error', 'Invalid coupon code');
  END IF;

  IF c.expires_at IS NOT NULL AND c.expires_at < now() THEN
    RETURN jsonb_build_object('valid', false, 'error', 'Coupon has expired');
  END IF;

  IF c.max_uses IS NOT NULL AND c.used_count >= c.max_uses THEN
    RETURN jsonb_build_object('valid', false, 'error', 'Coupon usage limit reached');
  END IF;

  IF _order_amount < c.min_order_amount THEN
    RETURN jsonb_build_object('valid', false, 'error', 'Order amount below minimum: $' || c.min_order_amount::text);
  END IF;

  IF c.discount_type = 'percentage' THEN
    discount := ROUND((_order_amount * c.discount_value) / 100, 4);
  ELSE
    discount := LEAST(c.discount_value, _order_amount);
  END IF;

  RETURN jsonb_build_object(
    'valid', true,
    'discount', discount,
    'discount_type', c.discount_type,
    'discount_value', c.discount_value,
    'code', c.code,
    'min_order_amount', c.min_order_amount
  );
END;
$$;