CREATE POLICY "Admins can create ticket messages"
ON public.ticket_messages FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));