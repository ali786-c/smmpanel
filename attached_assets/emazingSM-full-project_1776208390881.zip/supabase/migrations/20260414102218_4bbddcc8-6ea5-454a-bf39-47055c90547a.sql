
-- Drop the overly permissive policies
DROP POLICY IF EXISTS "Service role can insert wallet_transactions" ON public.wallet_transactions;
DROP POLICY IF EXISTS "Service role can insert notifications" ON public.notifications;

-- Wallet transactions: users can insert own (needed for system triggers via SECURITY DEFINER)
CREATE POLICY "Users can insert own wallet_transactions"
ON public.wallet_transactions
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Notifications: users can insert for themselves
CREATE POLICY "Users can insert own notifications"
ON public.notifications
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);
