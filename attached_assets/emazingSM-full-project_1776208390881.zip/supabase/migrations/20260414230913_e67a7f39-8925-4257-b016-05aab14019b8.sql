INSERT INTO public.system_settings (key, value)
VALUES
  ('landing_support_telegram_url', 'https://t.me/emazingsm'),
  ('landing_support_discord_url', 'https://discord.gg/emazingsm')
ON CONFLICT (key) DO NOTHING;