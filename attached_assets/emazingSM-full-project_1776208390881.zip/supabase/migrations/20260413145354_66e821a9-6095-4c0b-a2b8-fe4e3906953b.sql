
-- Admin can read all profiles
CREATE POLICY "Admins can view all profiles"
ON public.profiles FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can read all orders
CREATE POLICY "Admins can view all orders"
ON public.orders FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can update all orders
CREATE POLICY "Admins can update all orders"
ON public.orders FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can read all wallets
CREATE POLICY "Admins can view all wallets"
ON public.wallets FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can update all wallets
CREATE POLICY "Admins can update all wallets"
ON public.wallets FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can read all services (including inactive)
CREATE POLICY "Admins can view all services"
ON public.services FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can update services
CREATE POLICY "Admins can update services"
ON public.services FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can insert services
CREATE POLICY "Admins can insert services"
ON public.services FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Admin can read all wallet transactions
CREATE POLICY "Admins can view all transactions"
ON public.wallet_transactions FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can read all tickets
CREATE POLICY "Admins can view all tickets"
ON public.tickets FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can update tickets
CREATE POLICY "Admins can update tickets"
ON public.tickets FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can read all ticket messages
CREATE POLICY "Admins can view all ticket messages"
ON public.ticket_messages FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can read all refund logs
CREATE POLICY "Admins can view all refunds"
ON public.refund_log FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can read all referrals
CREATE POLICY "Admins can view all referrals"
ON public.referrals FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can read all user roles
CREATE POLICY "Admins can view all roles"
ON public.user_roles FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admin can manage user roles
CREATE POLICY "Admins can insert roles"
ON public.user_roles FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update roles"
ON public.user_roles FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete roles"
ON public.user_roles FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));
