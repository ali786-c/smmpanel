import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const results: Record<string, unknown> = {};

    let action = "all";
    try {
      const body = await req.json();
      if (body?.action) action = body.action;
    } catch {
      // no body = run all
    }

    // ─── 1. RE-ENGAGEMENT NOTIFICATIONS ───
    if (action === "all" || action === "re-engagement") {
      const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString();
      const sevenDaysAgo = new Date(Date.now() - 7 * 86400000).toISOString();

      const { data: allProfiles } = await supabase
        .from("profiles")
        .select("user_id")
        .eq("is_banned", false);

      if (allProfiles?.length) {
        const { data: activeOrders } = await supabase
          .from("orders")
          .select("user_id")
          .gte("created_at", thirtyDaysAgo);

        const activeUserIds = new Set((activeOrders || []).map((o) => o.user_id));

        const { data: recentNotifs } = await supabase
          .from("notifications")
          .select("user_id")
          .eq("type", "promo")
          .like("title", "%miss you%")
          .gte("created_at", sevenDaysAgo);

        const recentlyNotified = new Set((recentNotifs || []).map((n) => n.user_id));

        const inactiveUsers = allProfiles.filter(
          (p) => !activeUserIds.has(p.user_id) && !recentlyNotified.has(p.user_id)
        );

        if (inactiveUsers.length > 0) {
          const couponCode = `COMEBACK${new Date().toISOString().slice(0, 10).replace(/-/g, "")}`;
          const { data: existingCoupon } = await supabase
            .from("coupons").select("id").eq("code", couponCode).maybeSingle();

          if (!existingCoupon) {
            await supabase.from("coupons").insert({
              code: couponCode, discount_type: "percentage", discount_value: 10,
              is_active: true, expires_at: new Date(Date.now() + 7 * 86400000).toISOString(), min_order_amount: 0,
            });
          }

          const notifications = inactiveUsers.slice(0, 200).map((u) => ({
            user_id: u.user_id, title: "🔥 We miss you!",
            message: `It's been a while! Use code ${couponCode} for 10% off your next order.`,
            type: "promo", link: "/dashboard/new-order",
          }));

          let sent = 0;
          for (let i = 0; i < notifications.length; i += 50) {
            await supabase.from("notifications").insert(notifications.slice(i, i + 50));
            sent += Math.min(50, notifications.length - i);
          }
          results.reEngagement = { inactiveUsers: inactiveUsers.length, notified: sent, coupon: couponCode };
        } else {
          results.reEngagement = { inactiveUsers: 0, notified: 0 };
        }
      }
    }

    // ─── 2. AUTO PROMO CAMPAIGNS ───
    if (action === "all" || action === "auto-promo") {
      const now = new Date().toISOString();
      const { data: expired } = await supabase
        .from("coupons").select("id").eq("is_active", true).lt("expires_at", now).not("expires_at", "is", null);

      if (expired?.length) {
        for (const c of expired) {
          await supabase.from("coupons").update({ is_active: false }).eq("id", c.id);
        }
      }

      const dayOfWeek = new Date().getDay();
      if (dayOfWeek === 5) {
        const weekendCode = `WEEKEND${new Date().toISOString().slice(0, 10).replace(/-/g, "")}`;
        const { data: existsWeekend } = await supabase
          .from("coupons").select("id").eq("code", weekendCode).maybeSingle();

        if (!existsWeekend) {
          await supabase.from("coupons").insert({
            code: weekendCode, discount_type: "percentage", discount_value: 15,
            is_active: true, expires_at: new Date(Date.now() + 3 * 86400000).toISOString(), min_order_amount: 5,
          });

          const { data: activeProfiles } = await supabase
            .from("profiles").select("user_id").eq("is_banned", false);

          if (activeProfiles?.length) {
            const promoNotifs = activeProfiles.slice(0, 500).map((u) => ({
              user_id: u.user_id, title: "🎉 Weekend Special!",
              message: `Use code ${weekendCode} for 15% off all orders this weekend!`,
              type: "promo", link: "/dashboard/new-order",
            }));
            for (let i = 0; i < promoNotifs.length; i += 50) {
              await supabase.from("notifications").insert(promoNotifs.slice(i, i + 50));
            }
          }
          results.autoPromo = { weekendPromo: weekendCode, notified: activeProfiles?.length || 0 };
        } else {
          results.autoPromo = { weekendPromo: "already_exists" };
        }
      } else {
        results.autoPromo = { weekendPromo: "not_friday" };
      }
      results.autoPromo = { ...results.autoPromo as object, expiredDeactivated: expired?.length || 0 };
    }

    // ─── 3. BLOG AUTOPILOT ───
    if (action === "all" || action === "blog-autopilot") {
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const { data: todayPosts } = await supabase
        .from("blog_posts").select("id").gte("published_at", todayStart.toISOString()).eq("status", "published");

      if (!todayPosts?.length || todayPosts.length < 2) {
        try {
          const blogRes = await fetch(`${supabaseUrl}/functions/v1/generate-blog`, {
            method: "POST",
            headers: { Authorization: `Bearer ${supabaseKey}`, "Content-Type": "application/json" },
          });
          const blogResult = await blogRes.json();
          results.blogAutopilot = { generated: true, ...blogResult };
        } catch (blogErr) {
          results.blogAutopilot = { generated: false, error: blogErr instanceof Error ? blogErr.message : "Unknown" };
        }
      } else {
        results.blogAutopilot = { generated: false, reason: "already_published_today", count: todayPosts.length };
      }
    }

    // ─── 4. LOYALTY CHECK ───
    if (action === "all" || action === "loyalty-check") {
      results.loyaltyCheck = { note: "Handled by database trigger on order insert" };
    }

    // ─── 5. ABANDONED ORDER RECOVERY ───
    if (action === "all" || action === "abandoned-recovery") {
      // Users who visited new-order (have wallet) but haven't ordered in 3+ days
      const threeDaysAgo = new Date(Date.now() - 3 * 86400000).toISOString();
      const sevenDaysAgo = new Date(Date.now() - 7 * 86400000).toISOString();

      const { data: allUsers } = await supabase
        .from("wallets").select("user_id").gt("balance", 0);

      if (allUsers?.length) {
        // Users with balance but no recent orders
        const { data: recentOrderUsers } = await supabase
          .from("orders").select("user_id").gte("created_at", threeDaysAgo);
        const recentOrderSet = new Set((recentOrderUsers || []).map((o) => o.user_id));

        // Already notified about abandonment recently
        const { data: recentAbandoned } = await supabase
          .from("notifications").select("user_id").eq("type", "promo")
          .like("title", "%Finish your order%").gte("created_at", sevenDaysAgo);
        const alreadyNudged = new Set((recentAbandoned || []).map((n) => n.user_id));

        const abandonedUsers = allUsers.filter(
          (u) => !recentOrderSet.has(u.user_id) && !alreadyNudged.has(u.user_id)
        );

        if (abandonedUsers.length > 0) {
          const couponCode = `FINISH5`;
          const { data: existing } = await supabase
            .from("coupons").select("id").eq("code", couponCode).maybeSingle();
          if (!existing) {
            await supabase.from("coupons").insert({
              code: couponCode, discount_type: "percentage", discount_value: 5,
              is_active: true, expires_at: new Date(Date.now() + 14 * 86400000).toISOString(), min_order_amount: 0,
            });
          }

          const notifs = abandonedUsers.slice(0, 200).map((u) => ({
            user_id: u.user_id, title: "⏳ Finish your order!",
            message: `You have funds in your wallet! Use code ${couponCode} for 5% off. Don't let your balance sit idle.`,
            type: "promo", link: "/dashboard/new-order",
          }));
          for (let i = 0; i < notifs.length; i += 50) {
            await supabase.from("notifications").insert(notifs.slice(i, i + 50));
          }
          results.abandonedRecovery = { eligible: abandonedUsers.length, notified: notifs.length, coupon: couponCode };
        } else {
          results.abandonedRecovery = { eligible: 0, notified: 0 };
        }
      } else {
        results.abandonedRecovery = { eligible: 0, note: "No users with balance" };
      }
    }

    // ─── 6. MILESTONE CELEBRATIONS ───
    if (action === "all" || action === "milestone-celebration") {
      const milestones = [
        { count: 10, label: "10 orders", discount: 3, code: "MILE10" },
        { count: 50, label: "50 orders", discount: 5, code: "MILE50" },
        { count: 100, label: "100 orders", discount: 7, code: "MILE100" },
        { count: 500, label: "500 orders", discount: 10, code: "MILE500" },
      ];

      let celebrated = 0;
      // Get order counts per user
      const { data: orderCounts } = await supabase.rpc("has_role", { _user_id: "00000000-0000-0000-0000-000000000000", _role: "user" });
      // Instead, manually aggregate
      const { data: allOrders } = await supabase.from("orders").select("user_id");
      const userOrderCounts: Record<string, number> = {};
      (allOrders || []).forEach((o) => {
        userOrderCounts[o.user_id] = (userOrderCounts[o.user_id] || 0) + 1;
      });

      for (const [userId, count] of Object.entries(userOrderCounts)) {
        for (const m of milestones) {
          if (count >= m.count) {
            const refId = `milestone_orders_${m.count}_${userId}`;
            const { data: already } = await supabase
              .from("notifications").select("id").eq("user_id", userId)
              .like("title", `%${m.label}%`).limit(1);

            if (!already?.length) {
              // Ensure coupon exists
              const { data: cpn } = await supabase
                .from("coupons").select("id").eq("code", m.code).maybeSingle();
              if (!cpn) {
                await supabase.from("coupons").insert({
                  code: m.code, discount_type: "percentage", discount_value: m.discount,
                  is_active: true, min_order_amount: 0,
                });
              }

              await supabase.from("notifications").insert({
                user_id: userId, title: `🎉 ${m.label} milestone!`,
                message: `Amazing! You've placed ${m.label}! Use code ${m.code} for ${m.discount}% off your next order.`,
                type: "success", link: "/dashboard/new-order",
              });
              celebrated++;
            }
          }
        }
      }
      results.milestoneCelebration = { celebrated };
    }

    // ─── 7. SEASONAL AUTO-CAMPAIGNS ───
    if (action === "all" || action === "seasonal-campaigns") {
      const now = new Date();
      const month = now.getMonth() + 1; // 1-12
      const day = now.getDate();

      const seasonalEvents = [
        { month: 1, dayStart: 1, dayEnd: 2, code: "NEWYEAR25", discount: 25, label: "🎆 New Year Sale!" },
        { month: 2, dayStart: 12, dayEnd: 15, code: "LOVE20", discount: 20, label: "❤️ Valentine's Special!" },
        { month: 3, dayStart: 14, dayEnd: 18, code: "STPATRICK15", discount: 15, label: "🍀 St. Patrick's Day!" },
        { month: 7, dayStart: 3, dayEnd: 5, code: "JULY4TH20", discount: 20, label: "🇺🇸 Independence Day Sale!" },
        { month: 10, dayStart: 29, dayEnd: 31, code: "HALLOWEEN20", discount: 20, label: "🎃 Halloween Special!" },
        { month: 11, dayStart: 25, dayEnd: 30, code: "BLACKFRI30", discount: 30, label: "🖤 Black Friday Mega Sale!" },
        { month: 12, dayStart: 23, dayEnd: 26, code: "XMAS25", discount: 25, label: "🎄 Christmas Special!" },
        { month: 12, dayStart: 30, dayEnd: 31, code: "YEAREND20", discount: 20, label: "🥂 Year-End Clearance!" },
      ];

      const activeEvent = seasonalEvents.find(
        (e) => month === e.month && day >= e.dayStart && day <= e.dayEnd
      );

      if (activeEvent) {
        const { data: exists } = await supabase
          .from("coupons").select("id").eq("code", activeEvent.code).maybeSingle();

        if (!exists) {
          await supabase.from("coupons").insert({
            code: activeEvent.code, discount_type: "percentage", discount_value: activeEvent.discount,
            is_active: true, expires_at: new Date(now.getFullYear(), activeEvent.month - 1, activeEvent.dayEnd + 1).toISOString(),
            min_order_amount: 0,
          });

          // Notify all users
          const { data: users } = await supabase
            .from("profiles").select("user_id").eq("is_banned", false);
          if (users?.length) {
            const notifs = users.slice(0, 500).map((u) => ({
              user_id: u.user_id, title: activeEvent.label,
              message: `Use code ${activeEvent.code} for ${activeEvent.discount}% off! Limited time only.`,
              type: "promo", link: "/dashboard/new-order",
            }));
            for (let i = 0; i < notifs.length; i += 50) {
              await supabase.from("notifications").insert(notifs.slice(i, i + 50));
            }
          }
          results.seasonalCampaigns = { event: activeEvent.label, code: activeEvent.code, notified: users?.length || 0 };
        } else {
          results.seasonalCampaigns = { event: activeEvent.label, status: "already_created" };
        }
      } else {
        results.seasonalCampaigns = { event: "none_today" };
      }
    }

    // ─── 8. SOCIAL PROOF → BLOG ───
    if (action === "all" || action === "social-proof") {
      const { data: totalOrders } = await supabase.from("orders").select("id", { count: "exact" });
      const { data: totalUsers } = await supabase.from("profiles").select("id", { count: "exact" });
      const { data: completedOrders } = await supabase
        .from("orders").select("id", { count: "exact" }).eq("status", "Completed");

      const orderCount = totalOrders?.length || 0;
      const userCount = totalUsers?.length || 0;
      const completedCount = completedOrders?.length || 0;
      const successRate = orderCount > 0 ? ((completedCount / orderCount) * 100).toFixed(1) : "99.5";

      const todaySlug = `platform-stats-${new Date().toISOString().slice(0, 10)}`;
      const { data: existingPost } = await supabase
        .from("blog_posts").select("id").eq("slug", todaySlug).maybeSingle();

      if (!existingPost) {
        await supabase.from("blog_posts").insert({
          title: `Our Community: ${userCount.toLocaleString()} Users & ${orderCount.toLocaleString()} Campaigns`,
          slug: todaySlug,
          excerpt: `Join ${userCount.toLocaleString()} marketers who've launched ${orderCount.toLocaleString()} campaigns with a ${successRate}% success rate.`,
          content: `## Growing Together\n\nOur platform continues to grow with **${userCount.toLocaleString()} registered users** who have collectively launched **${orderCount.toLocaleString()} campaigns**.\n\n### Key Statistics\n- **${successRate}%** campaign success rate\n- **${userCount.toLocaleString()}** active marketers\n- **${orderCount.toLocaleString()}** total campaigns delivered\n\nWhether you're a solo creator or a marketing agency, our platform delivers consistent, reliable results for your social media growth strategy.\n\n### Why Marketers Choose Us\n1. **Fast Delivery** — Most orders start within minutes\n2. **Affordable Rates** — Competitive pricing across all platforms\n3. **24/7 Support** — Our team and AI assistant are always ready to help\n4. **API Access** — Automate your workflow with our developer-friendly API\n\nReady to grow? [Start your first campaign today](/dashboard/new-order).`,
          category: "Platform Updates",
          tags: ["social proof", "statistics", "growth"],
          status: "published",
          published_at: new Date().toISOString(),
          meta_title: `${userCount.toLocaleString()} Users Trust Our SMM Platform`,
          meta_description: `Join ${userCount.toLocaleString()} marketers. ${orderCount.toLocaleString()} campaigns delivered with ${successRate}% success rate.`,
          read_time: 2,
        });
        results.socialProof = { published: true, users: userCount, orders: orderCount, successRate };
      } else {
        results.socialProof = { published: false, reason: "already_posted_today" };
      }
    }

    // ─── 9. API USER NURTURING ───
    if (action === "all" || action === "api-nurturing") {
      const sevenDaysAgo = new Date(Date.now() - 7 * 86400000).toISOString();

      // Find users who have an API key but no orders via API
      const { data: apiUsers } = await supabase
        .from("profiles").select("user_id, api_key").not("api_key", "is", null);

      if (apiUsers?.length) {
        // Check who already got nurture notification
        const { data: nurtured } = await supabase
          .from("notifications").select("user_id").like("title", "%API%tutorial%").gte("created_at", sevenDaysAgo);
        const nurturedSet = new Set((nurtured || []).map((n) => n.user_id));

        // Check who has placed orders (any orders = they figured it out)
        const { data: orderers } = await supabase.from("orders").select("user_id");
        const orderUserSet = new Set((orderers || []).map((o) => o.user_id));

        const needsNurturing = apiUsers.filter(
          (u) => !nurturedSet.has(u.user_id) && !orderUserSet.has(u.user_id)
        );

        if (needsNurturing.length > 0) {
          const notifs = needsNurturing.slice(0, 100).map((u) => ({
            user_id: u.user_id, title: "📡 API tutorial — get started!",
            message: "You generated an API key but haven't placed your first API order yet. Check our API docs to get started in minutes!",
            type: "info", link: "/dashboard/api",
          }));
          for (let i = 0; i < notifs.length; i += 50) {
            await supabase.from("notifications").insert(notifs.slice(i, i + 50));
          }
          results.apiNurturing = { eligible: needsNurturing.length, notified: notifs.length };
        } else {
          results.apiNurturing = { eligible: 0, notified: 0 };
        }
      } else {
        results.apiNurturing = { eligible: 0, note: "No API key users" };
      }
    }

    return new Response(JSON.stringify({ success: true, results, timestamp: new Date().toISOString() }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    console.error("Growth automation error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
