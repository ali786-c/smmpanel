import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

// === COMPLIANCE NAME SANITIZER ===
// Removes/replaces non-compliant terms to make service names
// look professional and payment-processor friendly

const termReplacements: [RegExp, string][] = [
  // Remove risky brackets content
  [/\[BOTS?\]/gi, "[Automated]"],
  [/\[FAKE\]/gi, ""],
  [/\[CHEAP\]/gi, "[Value]"],
  [/\[EXCLUSIVE\]/gi, "[Premium]"],
  [/\[HQ\]/gi, "[High Quality]"],
  [/\[REAL\]/gi, "[Organic]"],
  
  // Replace risky standalone words
  [/\bbot(s)?\b/gi, "automated"],
  [/\bfake\b/gi, ""],
  [/\bcheap\b/gi, "value"],
  [/\bspam\b/gi, ""],
  [/\bdrop\b/gi, "gradual"],
  [/\bno drop\b/gi, "stable retention"],
  [/\bno refill\b/gi, "one-time delivery"],
  [/\binstant\b/gi, "fast"],
  [/\bSMM\b/gi, "Social Media Marketing"],
  [/\bSMM Panel\b/gi, "Marketing Platform"],
  
  // Rebrand growth/engagement terms
  [/\bAI Growth\b/gi, "Organic Growth"],
  [/\bAI Powered\b/gi, "Advanced"],
  [/\bAI\b/gi, "Advanced"],
  [/\bGrowth Package\b/gi, "Marketing Campaign"],
  [/\bGrowth Tool\b/gi, "Marketing Tool"],
  [/\bBuy\b/gi, "Get"],
  [/\bPurchase\b/gi, "Get"],
  
  // Rebrand action terms to marketing language
  [/\bFollowers\b/gi, "Audience Growth"],
  [/\bFollower\b/gi, "Audience Growth"],
  [/\bLikes\b/gi, "Engagement Boost"],
  [/\bLike\b/gi, "Engagement"],
  [/\bViews\b/gi, "Reach Amplification"],
  [/\bView\b/gi, "Reach"],
  [/\bComments\b/gi, "Community Interaction"],
  [/\bComment\b/gi, "Interaction"],
  [/\bShares\b/gi, "Content Distribution"],
  [/\bShare\b/gi, "Distribution"],
  [/\bSubscribers\b/gi, "Channel Growth"],
  [/\bSubscriber\b/gi, "Channel Growth"],
  [/\bPlays\b/gi, "Stream Promotion"],
  [/\bStreams\b/gi, "Stream Promotion"],
  [/\bWatch Hours?\b/gi, "Watch Time Campaign"],
  [/\bMentions\b/gi, "Brand Mentions Campaign"],
  [/\bSaves\b/gi, "Content Saves Campaign"],
  [/\bImpressions\b/gi, "Visibility Campaign"],
  [/\bClicks\b/gi, "Traffic Campaign"],
  [/\bRetweets?\b/gi, "Content Amplification"],
  [/\bReposts?\b/gi, "Content Redistribution"],
  [/\bUpvotes?\b/gi, "Community Endorsement"],
  [/\bDownloads?\b/gi, "Content Distribution"],
  [/\bMembers?\b/gi, "Community Growth"],
  [/\bReactions?\b/gi, "Engagement Boost"],
  
  // Clean up NFT/crypto references
  [/\bNFT\b/gi, "Digital Asset"],
  [/\bCrypto\b/gi, "Digital"],
  [/\bCrypto Services\b/gi, "Digital Platform Services"],
  [/\bOpenSea\b/gi, "Digital Marketplace"],
  [/\bCoinMarketCap\b/gi, "Market Analytics Platform"],
  [/\bCoinGecko\b/gi, "Analytics Platform"],
  [/\bRarible\b/gi, "Digital Gallery"],
  
  // Website traffic terms
  [/\bWebsite Traffic\b/gi, "Web Visibility Campaign"],
  [/\bTraffic\b/gi, "Visibility"],
  [/\bReferrer\b/gi, "Source"],
  [/\bChoose Referrer\b/gi, "Choose Source"],
  
  // Bracket metadata cleanup
  [/\[FROM APP\]/gi, "[Mobile]"],
  [/\[REAL LOOKING\]/gi, "[Premium Quality]"],
  [/\[LIFETIME GUARANTEED\]/gi, "[Lifetime Warranty]"],
  [/\[80% FEMALE\]/gi, "[Targeted Demographic]"],
  [/\[SEO\]/gi, "[Search Optimization]"],
  [/\[AR30\]/gi, "[30-Day Warranty]"],
  [/\[Non Drop\]/gi, "[Stable Retention]"],
  [/\[No\]/gi, ""],
  [/\[Nop\]/gi, ""],
  
  // Provider branding removal
  [/\bJAP\b/gi, "Premium"],
  [/\bJAP EXCLUSIVE\b/gi, "Premium Exclusive"],
  [/\bJustAnotherPanel\b/gi, ""],
  
  // Platform-specific risky categories
  [/\bKick Chat Bots?\b/gi, "Kick Live Chat Engagement"],
  [/\bChat Bots?\b/gi, "Live Chat Engagement"],
  [/\bAuto Likes\b/gi, "Automated Engagement"],
  [/\bAuto Followers\b/gi, "Automated Audience Growth"],
  [/\bAuto Views\b/gi, "Automated Reach"],
  [/\bAuto Comments\b/gi, "Automated Interaction"],
  
  // Additional platform detection
  [/\bBacklink\b/gi, "Authority Link"],
  [/\bPress Release Distribution\b/gi, "Media Distribution"],
  [/\bWatchlist\b/gi, "Portfolio Tracking"],
  [/\bPost Repost\b/gi, "Content Redistribution"],
  [/\bPost Views\b/gi, "Content Reach"],
  [/\bPost Likes\b/gi, "Content Engagement"],
  [/\bProfile Followers\b/gi, "Profile Audience Growth"],
];

function sanitizeServiceName(name: string): string {
  let sanitized = name;
  
  for (const [pattern, replacement] of termReplacements) {
    sanitized = sanitized.replace(pattern, replacement);
  }
  
  // Clean up double spaces, trailing/leading whitespace
  sanitized = sanitized.replace(/\s{2,}/g, " ").trim();
  // Clean up empty brackets
  sanitized = sanitized.replace(/\[\s*\]/g, "").trim();
  // Clean up double dashes
  sanitized = sanitized.replace(/\s*-\s*-\s*/g, " - ").trim();
  // Remove trailing dashes/hyphens
  sanitized = sanitized.replace(/\s*-\s*$/, "").trim();
  
  return sanitized;
}

function sanitizeCategory(category: string): string {
  let sanitized = category;
  // Apply same core replacements to categories
  for (const [pattern, replacement] of termReplacements) {
    sanitized = sanitized.replace(pattern, replacement);
  }
  return sanitized.replace(/\s{2,}/g, " ").trim();
}

// === END COMPLIANCE SANITIZER ===

function detectPlatform(name: string, category: string): string {
  const text = `${name} ${category}`.toLowerCase();
  if (text.includes("instagram")) return "Instagram";
  if (text.includes("tiktok") || text.includes("tik tok")) return "TikTok";
  if (text.includes("youtube")) return "YouTube";
  if (text.includes("twitter") || text.includes(" x ")) return "Twitter";
  if (text.includes("facebook") || text.includes("fb")) return "Facebook";
  if (text.includes("telegram")) return "Telegram";
  if (text.includes("spotify")) return "Spotify";
  if (text.includes("discord")) return "Discord";
  if (text.includes("twitch")) return "Twitch";
  if (text.includes("linkedin")) return "LinkedIn";
  if (text.includes("snapchat")) return "Snapchat";
  if (text.includes("pinterest")) return "Pinterest";
  if (text.includes("reddit")) return "Reddit";
  if (text.includes("soundcloud")) return "SoundCloud";
  if (text.includes("threads")) return "Threads";
  if (text.includes("kick.com") || text.includes("kick ")) return "Kick";
  if (text.includes("coinmarketcap") || text.includes("coingecko") || text.includes("opensea") || text.includes("rarible")) return "Digital Assets";
  if (text.includes("website traffic") || text.includes("web traffic")) return "Web Traffic";
  if (text.includes("clubhouse")) return "Clubhouse";
  if (text.includes("dailymotion")) return "Dailymotion";
  if (text.includes("medium")) return "Medium";
  if (text.includes("bluesky")) return "BlueSky";
  if (text.includes("kwai")) return "Kwai";
  if (text.includes("likee")) return "Likee";
  if (text.includes("line")) return "Line";
  if (text.includes("dribble") || text.includes("dribbble")) return "Dribbble";
  if (text.includes("datpiff")) return "Datpiff";
  if (text.includes("coub")) return "Coub";
  return "Other";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiUrl = Deno.env.get("PROVIDER_API_URL");
    const apiKey = Deno.env.get("PROVIDER_API_KEY");
    console.log("PROVIDER_API_URL length:", apiUrl?.length, "starts with http:", apiUrl?.startsWith("http"));
    if (!apiUrl || !apiUrl.startsWith("http")) {
      return new Response(JSON.stringify({ error: "PROVIDER_API_URL not configured correctly. Current value length: " + (apiUrl?.length || 0) }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check if compliance filter is enabled (default: true)
    const { data: settingRow } = await adminClient
      .from("system_settings")
      .select("value")
      .eq("key", "compliance_name_filter")
      .maybeSingle();
    const complianceFilterEnabled = settingRow?.value !== "false";

    // Fetch all services from provider
    const body = new URLSearchParams({ key: apiKey!, action: "services" });
    const res = await fetch(apiUrl, { method: "POST", body });
    const services = await res.json();

    if (!Array.isArray(services)) {
      return new Response(JSON.stringify({ error: "Invalid provider response" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let upserted = 0;
    let sanitizedCount = 0;

    // Process in batches of 50
    for (let i = 0; i < services.length; i += 50) {
      const batch = services.slice(i, i + 50).map((s: any) => {
        const originalName = s.name || "";
        const originalCategory = s.category || "Other";
        const name = complianceFilterEnabled ? sanitizeServiceName(originalName) : originalName;
        const category = complianceFilterEnabled ? sanitizeCategory(originalCategory) : originalCategory;
        
        if (name !== originalName) sanitizedCount++;

        return {
          external_service_id: s.service,
          name,
          category,
          platform: detectPlatform(originalName, originalCategory), // Use original for detection
          type: s.type || "Default",
          rate: parseFloat(s.rate) * 1.4, // 40% markup
          min_order: parseInt(s.min) || 1,
          max_order: parseInt(s.max) || 100000,
          refill: s.refill === true,
          cancel: s.cancel === true,
          is_active: true,
        };
      });

      const { error } = await adminClient
        .from("services")
        .upsert(batch, { onConflict: "external_service_id" });

      if (!error) upserted += batch.length;
    }

    return new Response(JSON.stringify({ 
      success: true, 
      synced: upserted, 
      total: services.length,
      sanitized: sanitizedCount,
      compliance_filter: complianceFilterEnabled
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Sync error:", err);
    return new Response(JSON.stringify({ error: "Sync failed", details: String(err) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
