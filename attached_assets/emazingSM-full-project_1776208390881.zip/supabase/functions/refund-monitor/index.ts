import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const PROVIDER_API_URL = Deno.env.get("PROVIDER_API_URL")!;
const PROVIDER_API_KEY = Deno.env.get("PROVIDER_API_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

async function providerRequest(params: Record<string, string>) {
  const body = new URLSearchParams({ key: PROVIDER_API_KEY, ...params });
  const res = await fetch(PROVIDER_API_URL, { method: "POST", body });
  return res.json();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Get all non-completed orders
    const { data: activeOrders } = await adminClient
      .from("orders")
      .select("id, user_id, external_order_id, cost, status, service_id")
      .in("status", ["Processing", "In Progress", "Pending"])
      .limit(100);

    if (!activeOrders?.length) {
      return new Response(JSON.stringify({ message: "No active orders to check" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let refunded = 0;
    let updated = 0;
    const serviceFailures: Record<string, number> = {};

    for (const order of activeOrders) {
      if (!order.external_order_id) continue;

      const statusData = await providerRequest({
        action: "status",
        order: String(order.external_order_id),
      });

      if (!statusData.status) continue;

      const newStatus = statusData.status;
      const remains = parseInt(statusData.remains) || 0;

      // Update order status
      await adminClient
        .from("orders")
        .update({
          status: newStatus,
          start_count: parseInt(statusData.start_count) || 0,
          remains,
        })
        .eq("id", order.id);
      updated++;

      // Track failures for service health
      if (newStatus === "Cancelled" || newStatus === "Partial") {
        const sid = order.service_id;
        if (sid) serviceFailures[sid] = (serviceFailures[sid] || 0) + 1;
      }

      // Handle refunds for cancelled/partial orders
      if (newStatus === "Cancelled" || (newStatus === "Partial" && remains > 0)) {
        const refundAmount = newStatus === "Cancelled"
          ? parseFloat(String(order.cost))
          : parseFloat(((remains / (remains + parseInt(statusData.start_count || "0"))) * parseFloat(String(order.cost))).toFixed(4));

        if (refundAmount <= 0) continue;

        // Check if already refunded
        const { data: existingRefund } = await adminClient
          .from("refund_log")
          .select("id")
          .eq("order_id", order.id)
          .eq("status", "completed")
          .single();

        if (existingRefund) continue;

        // Credit user wallet
        const { data: wallet } = await adminClient
          .from("wallets")
          .select("balance")
          .eq("user_id", order.user_id)
          .single();

        if (wallet) {
          await adminClient
            .from("wallets")
            .update({ balance: parseFloat(wallet.balance) + refundAmount })
            .eq("user_id", order.user_id);

          // Log refund
          await adminClient.from("refund_log").insert({
            order_id: order.id,
            user_id: order.user_id,
            amount: refundAmount,
            reason: `Auto-refund: order ${newStatus}`,
            status: "completed",
          });

          // Log wallet transaction
          await adminClient.from("wallet_transactions").insert({
            user_id: order.user_id,
            type: "refund",
            amount: refundAmount,
            description: `Auto-refund for order ${newStatus}`,
            reference_id: order.id,
          });

          // Update order status to Refunded
          await adminClient
            .from("orders")
            .update({ status: "Refunded" })
            .eq("id", order.id);

          refunded++;
        }
      }
    }

    // Update service health scores based on failures
    for (const [serviceId, failures] of Object.entries(serviceFailures)) {
      const { data: service } = await adminClient
        .from("services")
        .select("health_score")
        .eq("id", serviceId)
        .single();

      if (service) {
        const newScore = Math.max(0, service.health_score - failures * 5);
        const updates: any = { health_score: newScore };

        // Auto-disable services with very low health
        if (newScore < 20) {
          updates.is_active = false;
        }
        // Deprioritize unhealthy services
        if (newScore < 50) {
          updates.display_order = 9999;
        }

        await adminClient.from("services").update(updates).eq("id", serviceId);
      }
    }

    return new Response(
      JSON.stringify({ success: true, checked: activeOrders.length, updated, refunded }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: "Monitor failed" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
