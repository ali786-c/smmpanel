import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify the user's JWT
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);
    const userId = user.id;

    // Delete user data from all public tables
    await Promise.all([
      adminClient.from("favorite_services").delete().eq("user_id", userId),
      adminClient.from("notification_preferences").delete().eq("user_id", userId),
      adminClient.from("notifications").delete().eq("user_id", userId),
      adminClient.from("wallet_transactions").delete().eq("user_id", userId),
      adminClient.from("referrals").delete().eq("referrer_id", userId),
      adminClient.from("referrals").delete().eq("referred_id", userId),
      adminClient.from("user_roles").delete().eq("user_id", userId),
      adminClient.from("activity_log").delete().eq("actor_id", userId),
    ]);

    // Delete tickets and their messages
    const { data: tickets } = await adminClient.from("tickets").select("id").eq("user_id", userId);
    if (tickets && tickets.length > 0) {
      const ticketIds = tickets.map((t: any) => t.id);
      await adminClient.from("ticket_messages").delete().in("ticket_id", ticketIds);
      await adminClient.from("tickets").delete().eq("user_id", userId);
    }

    // Delete orders, refund_log, wallets, profiles
    await adminClient.from("refund_log").delete().eq("user_id", userId);
    await adminClient.from("orders").delete().eq("user_id", userId);
    await adminClient.from("wallets").delete().eq("user_id", userId);
    await adminClient.from("profiles").delete().eq("user_id", userId);

    // Finally delete the auth user
    const { error: deleteError } = await adminClient.auth.admin.deleteUser(userId);
    if (deleteError) {
      console.error("Failed to delete auth user:", deleteError);
      return new Response(JSON.stringify({ error: "Failed to delete account" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Delete user error:", err);
    return new Response(JSON.stringify({ error: "Internal error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
