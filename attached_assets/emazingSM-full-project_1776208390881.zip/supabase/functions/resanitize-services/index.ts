import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

const termReplacements: [RegExp, string][] = [
  [/\[BOTS?\]/gi, "[Automated]"],
  [/\[FAKE\]/gi, ""],
  [/\[CHEAP\]/gi, "[Value]"],
  [/\[EXCLUSIVE\]/gi, "[Premium]"],
  [/\[HQ\]/gi, "[High Quality]"],
  [/\[REAL\]/gi, "[Organic]"],
  [/\bbot(s)?\b/gi, "automated"],
  [/\bfake\b/gi, ""],
  [/\bcheap\b/gi, "value"],
  [/\bspam\b/gi, ""],
  [/\bdrop\b/gi, "gradual"],
  [/\bno drop\b/gi, "stable retention"],
  [/\bno refill\b/gi, "one-time delivery"],
  [/\binstant\b/gi, "fast"],
  [/\bSMM\b/gi, "Social Media Marketing"],
  [/\bSMM Panel\b/gi, "Marketing Platform"],
  [/\bFollowers\b/gi, "Audience Growth"],
  [/\bFollower\b/gi, "Audience Growth"],
  [/\bLikes\b/gi, "Engagement Boost"],
  [/\bLike\b/gi, "Engagement"],
  [/\bViews\b/gi, "Reach Amplification"],
  [/\bView\b/gi, "Reach"],
  [/\bComments\b/gi, "Community Interaction"],
  [/\bComment\b/gi, "Interaction"],
  [/\bShares\b/gi, "Content Distribution"],
  [/\bShare\b/gi, "Distribution"],
  [/\bSubscribers\b/gi, "Channel Growth"],
  [/\bSubscriber\b/gi, "Channel Growth"],
  [/\bPlays\b/gi, "Stream Promotion"],
  [/\bStreams\b/gi, "Stream Promotion"],
  [/\bWatch Hours?\b/gi, "Watch Time Campaign"],
  [/\bMentions\b/gi, "Brand Mentions Campaign"],
  [/\bSaves\b/gi, "Content Saves Campaign"],
  [/\bImpressions\b/gi, "Visibility Campaign"],
  [/\bClicks\b/gi, "Traffic Campaign"],
  [/\bRetweets?\b/gi, "Content Amplification"],
  [/\bReposts?\b/gi, "Content Redistribution"],
  [/\bUpvotes?\b/gi, "Community Endorsement"],
  [/\bDownloads?\b/gi, "Content Distribution"],
  [/\bMembers?\b/gi, "Community Growth"],
  [/\bReactions?\b/gi, "Engagement Boost"],
  [/\bNFT\b/gi, "Digital Asset"],
  [/\bCrypto\b/gi, "Digital"],
  [/\bBacklink\b/gi, "Authority Link"],
  [/\bTraffic\b/gi, "Visibility"],
  [/\bAuto Likes\b/gi, "Automated Engagement"],
  [/\bAuto Followers\b/gi, "Automated Audience Growth"],
  [/\bAuto Views\b/gi, "Automated Reach"],
  [/\bAuto Comments\b/gi, "Automated Interaction"],
  [/\bChat Bots?\b/gi, "Live Chat Engagement"],
  [/\bBuy\b/gi, "Get"],
  [/\bPurchase\b/gi, "Get"],
  [/\bAI\b/gi, "Advanced"],
  [/\bWebsite Traffic\b/gi, "Web Visibility Campaign"],
  [/\[FROM APP\]/gi, "[Mobile]"],
  [/\[REAL LOOKING\]/gi, "[Premium Quality]"],
  [/\[LIFETIME GUARANTEED\]/gi, "[Lifetime Warranty]"],
  [/\[Non Drop\]/gi, "[Stable Retention]"],
  [/\bJustAnotherPanel\b/gi, ""],
  [/\bJAP\b/gi, "Premium"],
];

function sanitize(name: string): string {
  let s = name;
  for (const [pattern, replacement] of termReplacements) {
    s = s.replace(pattern, replacement);
  }
  return s.replace(/\s{2,}/g, " ").replace(/\[\s*\]/g, "").replace(/\s*-\s*-\s*/g, " - ").replace(/\s*-\s*$/, "").trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Fetch all services
    const { data: services, error } = await adminClient.from("services").select("id, name, category");
    if (error) throw error;

    let updated = 0;
    for (const svc of services || []) {
      const newName = sanitize(svc.name);
      const newCategory = sanitize(svc.category);
      if (newName !== svc.name || newCategory !== svc.category) {
        await adminClient.from("services").update({ name: newName, category: newCategory }).eq("id", svc.id);
        updated++;
      }
    }

    return new Response(JSON.stringify({ success: true, total: services?.length || 0, updated }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
