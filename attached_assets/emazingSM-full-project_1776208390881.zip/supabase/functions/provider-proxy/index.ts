import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const PROVIDER_API_URL = Deno.env.get("PROVIDER_API_URL")!;
const PROVIDER_API_KEY = Deno.env.get("PROVIDER_API_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

async function providerRequest(params: Record<string, string>) {
  const body = new URLSearchParams({ key: PROVIDER_API_KEY, ...params });
  const res = await fetch(PROVIDER_API_URL, { method: "POST", body });
  return res.json();
}

async function getAuthUser(req: Request) {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) return null;
  const supabase = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) return null;
  return data.user;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { action, ...params } = await req.json();

    // Public action: fetch services (no auth needed)
    if (action === "services") {
      const data = await providerRequest({ action: "services" });
      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // All other actions require auth
    const user = await getAuthUser(req);
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check if user is banned
    const { data: profile } = await adminClient
      .from("profiles")
      .select("is_banned")
      .eq("user_id", user.id)
      .single();

    if (profile?.is_banned) {
      return new Response(JSON.stringify({ error: "Your account has been suspended. Please contact support." }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "add") {
      const { serviceId: service_id, link, quantity, runs, interval, couponCode } = params;
      if (!service_id || !link || !quantity) {
        return new Response(JSON.stringify({ error: "Missing required fields" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Get service details
      const { data: service } = await adminClient
        .from("services")
        .select("*")
        .eq("id", service_id)
        .single();

      if (!service) {
        return new Response(JSON.stringify({ error: "Service not found" }), {
          status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      let cost = parseFloat(((service.rate / 1000) * quantity).toFixed(4));
      const providerCost = parseFloat(((service.rate / 1000) * quantity * 0.7).toFixed(4));

      // Apply coupon if provided
      let couponId: string | null = null;
      if (couponCode) {
        const { data: coupon } = await adminClient
          .from("coupons")
          .select("*")
          .eq("code", couponCode)
          .eq("is_active", true)
          .single();

        if (coupon) {
          const notExpired = !coupon.expires_at || new Date(coupon.expires_at) > new Date();
          const notMaxed = !coupon.max_uses || coupon.used_count < coupon.max_uses;
          const meetsMin = cost >= Number(coupon.min_order_amount);

          if (notExpired && notMaxed && meetsMin) {
            let discount = 0;
            if (coupon.discount_type === "percentage") {
              discount = parseFloat(((cost * Number(coupon.discount_value)) / 100).toFixed(4));
            } else {
              discount = Math.min(Number(coupon.discount_value), cost);
            }
            cost = Math.max(0, cost - discount);
            couponId = coupon.id;

            // Increment used_count
            await adminClient
              .from("coupons")
              .update({ used_count: coupon.used_count + 1 })
              .eq("id", coupon.id);
          }
        }
      }

      // Check balance
      const { data: wallet } = await adminClient
        .from("wallets")
        .select("balance")
        .eq("user_id", user.id)
        .single();

      if (!wallet || parseFloat(wallet.balance) < cost) {
        return new Response(JSON.stringify({ error: "Insufficient balance" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Place order with provider (include drip-feed params if set)
      const providerParams: Record<string, string> = {
        action: "add",
        service: String(service.external_service_id),
        link,
        quantity: String(quantity),
      };
      if (runs && interval) {
        providerParams.runs = String(runs);
        providerParams.interval = String(interval);
      }

      const providerRes = await providerRequest(providerParams);

      if (providerRes.error) {
        return new Response(JSON.stringify({ error: "Order failed. Please try again." }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Deduct balance
      await adminClient
        .from("wallets")
        .update({ balance: parseFloat(wallet.balance) - cost })
        .eq("user_id", user.id);

      // Save order
      const { data: order } = await adminClient
        .from("orders")
        .insert({
          user_id: user.id,
          service_id: service.id,
          external_order_id: providerRes.order,
          link,
          quantity,
          cost,
          provider_cost: providerCost,
          profit: cost - providerCost,
          status: "Processing",
        })
        .select()
        .single();

      // Log transaction
      await adminClient
        .from("wallet_transactions")
        .insert({
          user_id: user.id,
          type: "order",
          amount: -cost,
          description: `Order for ${service.name}${couponCode ? ` (coupon: ${couponCode})` : ""}`,
          reference_id: order?.id,
        });

      return new Response(JSON.stringify({ success: true, order_id: order?.id }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "status") {
      const { order_id } = params;
      const { data: order } = await adminClient
        .from("orders")
        .select("external_order_id")
        .eq("id", order_id)
        .eq("user_id", user.id)
        .single();

      if (!order?.external_order_id) {
        return new Response(JSON.stringify({ error: "Order not found" }), {
          status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const data = await providerRequest({
        action: "status",
        order: String(order.external_order_id),
      });

      if (data.status) {
        await adminClient
          .from("orders")
          .update({
            status: data.status,
            start_count: parseInt(data.start_count) || 0,
            remains: parseInt(data.remains) || 0,
          })
          .eq("id", order_id);
      }

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "refill") {
      const { orderId } = params;
      const data = await providerRequest({
        action: "refill",
        order: String(orderId),
      });

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "cancel") {
      const { orderId, order_ids } = params;
      
      if (orderId) {
        // Single cancel
        const data = await providerRequest({ action: "cancel", orders: String(orderId) });
        return new Response(JSON.stringify(data), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      
      if (order_ids) {
        // Bulk cancel
        const { data: orders } = await adminClient
          .from("orders")
          .select("id, external_order_id")
          .in("id", order_ids)
          .eq("user_id", user.id);

        if (!orders?.length) {
          return new Response(JSON.stringify({ error: "No orders found" }), {
            status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const externalIds = orders.map((o) => String(o.external_order_id)).join(",");
        const data = await providerRequest({ action: "cancel", orders: externalIds });

        return new Response(JSON.stringify(data), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ error: "Missing order ID" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "balance") {
      const { data: role } = await adminClient
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .single();

      if (!role) {
        return new Response(JSON.stringify({ error: "Forbidden" }), {
          status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const data = await providerRequest({ action: "balance" });
      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
