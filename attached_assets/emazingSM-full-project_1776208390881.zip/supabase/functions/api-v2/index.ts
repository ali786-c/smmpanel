const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const PROVIDER_API_URL = Deno.env.get('PROVIDER_API_URL') || '';
const PROVIDER_API_KEY = Deno.env.get('PROVIDER_API_KEY') || '';

// Simple in-memory rate limiter (per-isolate, resets on cold start)
const rateLimits = new Map<string, { count: number; reset: number }>();
const RATE_LIMIT = 100; // requests per minute
const RATE_WINDOW = 60_000; // 1 minute

function checkRateLimit(apiKey: string): boolean {
  const now = Date.now();
  const entry = rateLimits.get(apiKey);
  if (!entry || now > entry.reset) {
    rateLimits.set(apiKey, { count: 1, reset: now + RATE_WINDOW });
    return true;
  }
  if (entry.count >= RATE_LIMIT) return false;
  entry.count++;
  return true;
}

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function providerRequest(params: Record<string, string>) {
  const res = await fetch(PROVIDER_API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: PROVIDER_API_KEY, ...params }),
  });
  return res.json();
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: 'Invalid JSON' }, 400);
  }

  const apiKey = String(body.key || '');
  const action = String(body.action || '');

  if (!apiKey) return jsonResponse({ error: 'Missing API key' }, 401);
  if (!action) return jsonResponse({ error: 'Missing action' }, 400);

  // Authenticate via API key
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const { data: profile, error: profileErr } = await supabase
    .from('profiles')
    .select('user_id')
    .eq('api_key', apiKey)
    .single();

  if (profileErr || !profile) {
    return jsonResponse({ error: 'Invalid API key' }, 401);
  }

  const userId = profile.user_id;

  // Rate limit
  if (!checkRateLimit(apiKey)) {
    return jsonResponse({ error: 'Rate limit exceeded. Max 100 requests/minute.' }, 429);
  }

  try {
    switch (action) {
      case 'services': {
        const { data: services } = await supabase
          .from('services')
          .select('external_service_id, name, category, rate, min_order, max_order, type, refill, cancel')
          .eq('is_active', true)
          .order('display_order');

        return jsonResponse(
          (services || []).map((s) => ({
            service: s.external_service_id,
            name: s.name,
            category: s.category,
            rate: String(s.rate),
            min: String(s.min_order),
            max: String(s.max_order),
            type: s.type,
            refill: s.refill,
            cancel: s.cancel,
          }))
        );
      }

      case 'add': {
        const serviceId = Number(body.service);
        const link = String(body.link || '');
        const quantity = Number(body.quantity);

        if (!serviceId || !link || !quantity) {
          return jsonResponse({ error: 'Missing service, link, or quantity' }, 400);
        }

        // Find service
        const { data: service } = await supabase
          .from('services')
          .select('*')
          .eq('external_service_id', serviceId)
          .eq('is_active', true)
          .single();

        if (!service) return jsonResponse({ error: 'Service not found or inactive' }, 404);

        if (quantity < service.min_order || quantity > service.max_order) {
          return jsonResponse({ error: `Quantity must be between ${service.min_order} and ${service.max_order}` }, 400);
        }

        const cost = (service.rate / 1000) * quantity;

        // Check balance
        const { data: wallet } = await supabase
          .from('wallets')
          .select('balance')
          .eq('user_id', userId)
          .single();

        if (!wallet || wallet.balance < cost) {
          return jsonResponse({ error: 'Insufficient balance' }, 400);
        }

        // Place order with provider
        const providerRes = await providerRequest({
          action: 'add',
          service: String(serviceId),
          link,
          quantity: String(quantity),
        });

        if (providerRes.error) {
          return jsonResponse({ error: providerRes.error }, 400);
        }

        const providerCost = (service.rate / 1.4 / 1000) * quantity; // reverse 40% markup
        const profit = cost - providerCost;

        // Deduct balance
        await supabase
          .from('wallets')
          .update({ balance: wallet.balance - cost })
          .eq('user_id', userId);

        // Insert order
        const { data: order } = await supabase
          .from('orders')
          .insert({
            user_id: userId,
            service_id: service.id,
            external_order_id: providerRes.order,
            link,
            quantity,
            cost,
            provider_cost: providerCost,
            profit,
            status: 'Pending',
          })
          .select('id')
          .single();

        // Log transaction
        await supabase.from('wallet_transactions').insert({
          user_id: userId,
          type: 'order',
          amount: -cost,
          payment_method: 'API',
          description: `Order #${providerRes.order}`,
          status: 'completed',
        });

        return jsonResponse({ order: providerRes.order });
      }

      case 'status': {
        const orderId = body.order ? Number(body.order) : null;
        if (!orderId) return jsonResponse({ error: 'Missing order ID' }, 400);

        const { data: order } = await supabase
          .from('orders')
          .select('external_order_id, status, start_count, remains, quantity')
          .eq('external_order_id', orderId)
          .eq('user_id', userId)
          .single();

        if (!order) return jsonResponse({ error: 'Order not found' }, 404);

        return jsonResponse({
          charge: String(order.remains || 0),
          start_count: String(order.start_count || 0),
          status: order.status,
          remains: String(order.remains || 0),
          currency: 'USD',
        });
      }

      case 'balance': {
        const { data: wallet } = await supabase
          .from('wallets')
          .select('balance')
          .eq('user_id', userId)
          .single();

        return jsonResponse({
          balance: String(wallet?.balance || 0),
          currency: 'USD',
        });
      }

      case 'refill': {
        const orderId = body.order ? Number(body.order) : null;
        if (!orderId) return jsonResponse({ error: 'Missing order ID' }, 400);

        const { data: order } = await supabase
          .from('orders')
          .select('external_order_id')
          .eq('external_order_id', orderId)
          .eq('user_id', userId)
          .single();

        if (!order) return jsonResponse({ error: 'Order not found' }, 404);

        const providerRes = await providerRequest({ action: 'refill', order: String(orderId) });
        return jsonResponse(providerRes);
      }

      case 'cancel': {
        const orders = String(body.orders || body.order || '');
        if (!orders) return jsonResponse({ error: 'Missing order ID(s)' }, 400);

        const providerRes = await providerRequest({ action: 'cancel', orders });
        return jsonResponse(providerRes);
      }

      default:
        return jsonResponse({ error: `Unknown action: ${action}` }, 400);
    }
  } catch (err) {
    return jsonResponse({ error: 'Internal server error' }, 500);
  }
});
