import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const blogLanguages = [
  { code: "en", name: "English", instruction: "Write in English." },
  { code: "es", name: "Spanish", instruction: "Write entirely in Spanish (Español)." },
  { code: "fr", name: "French", instruction: "Write entirely in French (Français)." },
  { code: "de", name: "German", instruction: "Write entirely in German (Deutsch)." },
  { code: "it", name: "Italian", instruction: "Write entirely in Italian (Italiano)." },
  { code: "pt", name: "Portuguese", instruction: "Write entirely in Portuguese (Português)." },
  { code: "nl", name: "Dutch", instruction: "Write entirely in Dutch (Nederlands)." },
  { code: "tr", name: "Turkish", instruction: "Write entirely in Turkish (Türkçe)." },
  { code: "ru", name: "Russian", instruction: "Write entirely in Russian (Русский)." },
  { code: "ar", name: "Arabic", instruction: "Write entirely in Arabic (العربية)." },
  { code: "hi", name: "Hindi", instruction: "Write entirely in Hindi (हिन्दी)." },
  { code: "bn", name: "Bengali", instruction: "Write entirely in Bengali (বাংলা)." },
  { code: "ko", name: "Korean", instruction: "Write entirely in Korean (한국어)." },
  { code: "ja", name: "Japanese", instruction: "Write entirely in Japanese (日本語)." },
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");

    if (!lovableApiKey) {
      return new Response(JSON.stringify({ error: "LOVABLE_API_KEY not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const topics = [
      "Instagram marketing strategies for small businesses in 2026",
      "How to grow your TikTok audience organically",
      "YouTube content promotion best practices",
      "Social media campaign optimization tips",
      "Twitter/X engagement strategies for brands",
      "Facebook marketing ROI improvement techniques",
      "Content calendar planning for social media agencies",
      "Influencer collaboration strategies for audience growth",
      "Social media analytics and performance tracking guide",
      "Building a social media marketing agency from scratch",
      "Video marketing trends and content promotion strategies",
      "Community building on Telegram and Discord for brands",
      "Paid vs organic social media growth comparison",
      "Social media crisis management for agencies",
      "Cross-platform marketing campaign coordination",
      "How to use Reels and Shorts for brand awareness",
      "E-commerce social media marketing strategies",
      "Local business social media marketing guide",
      "Social media advertising budget optimization",
      "User-generated content strategies for engagement",
    ];

    const randomTopic = topics[Math.floor(Math.random() * topics.length)];
    const randomLang = blogLanguages[Math.floor(Math.random() * blogLanguages.length)];
    const timestamp = Date.now();

    const aiResponse = await fetch("https://ai.lovable.dev/api/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${lovableApiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are a social media marketing expert writing SEO-optimized blog articles. ${randomLang.instruction} Write professional, informative content that helps agencies and marketers grow their clients' social media presence. Never mention buying followers, likes, or artificial engagement. Focus on legitimate marketing strategies, campaign optimization, and audience growth through quality content and strategic promotion. Return a JSON object with these fields: title, slug (url-friendly, always use Latin characters for the slug even if writing in non-Latin script), excerpt (2 sentences), content (full HTML article with h2, h3, p, ul, li tags, 800-1200 words), category (one of: Instagram, YouTube, TikTok, Twitter, Facebook, Strategy, Analytics, Agency), tags (array of 3-5 relevant tags in the article language), meta_title (under 60 chars), meta_description (under 160 chars), read_time (estimated minutes).`,
          },
          {
            role: "user",
            content: `Write an SEO-optimized blog article about: ${randomTopic}. Language: ${randomLang.name}. Make it unique with a timestamp seed: ${timestamp}`,
          },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!aiResponse.ok) {
      const errBody = await aiResponse.text();
      throw new Error(`AI API error [${aiResponse.status}]: ${errBody}`);
    }

    const aiData = await aiResponse.json();
    const content = aiData.choices?.[0]?.message?.content;
    if (!content) throw new Error("No content from AI");

    const article = JSON.parse(content);

    const slug = `${article.slug}-${randomLang.code}-${timestamp}`.slice(0, 200);

    const { error: insertError } = await supabase.from("blog_posts").insert({
      title: article.title,
      slug,
      excerpt: article.excerpt,
      content: article.content,
      category: article.category,
      tags: [...(article.tags || []), randomLang.code, randomLang.name],
      status: "published",
      published_at: new Date().toISOString(),
      read_time: article.read_time || 5,
      meta_title: article.meta_title || article.title.slice(0, 60),
      meta_description: article.meta_description || article.excerpt.slice(0, 160),
    });

    if (insertError) throw new Error(`DB insert error: ${insertError.message}`);

    return new Response(JSON.stringify({ success: true, title: article.title, slug, language: randomLang.name }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    console.error("Blog generation error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});