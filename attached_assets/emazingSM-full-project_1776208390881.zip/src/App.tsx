import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import ProtectedRoute from "@/components/ProtectedRoute";
import AdminRoute from "@/components/AdminRoute";
import CookieConsent from "@/components/CookieConsent";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Dashboard from "./pages/Dashboard";
import Services from "./pages/dashboard/Services";
import NewOrder from "./pages/dashboard/NewOrder";
import MassOrder from "./pages/dashboard/MassOrder";
import Orders from "./pages/dashboard/Orders";
import WalletPage from "./pages/dashboard/WalletPage";
import Support from "./pages/dashboard/Support";
import Tickets from "./pages/dashboard/Tickets";
import Updates from "./pages/dashboard/Updates";
import SettingsPage from "./pages/dashboard/Settings";
import ApiDocs from "./pages/dashboard/ApiDocs";
import Affiliates from "./pages/dashboard/Affiliates";
import OrderDetail from "./pages/dashboard/OrderDetail";
import SpendingAnalytics from "./pages/dashboard/SpendingAnalytics";
import AccountManagement from "./pages/dashboard/AccountManagement";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminUserDetail from "./pages/admin/AdminUserDetail";
import AdminServices from "./pages/admin/AdminServices";
import AdminTickets from "./pages/admin/AdminTickets";
import AdminOrders from "./pages/admin/AdminOrders";
import AdminFinance from "./pages/admin/AdminFinance";
import AdminBlog from "./pages/admin/AdminBlog";
import AdminAnnouncements from "./pages/admin/AdminAnnouncements";
import AdminCoupons from "./pages/admin/AdminCoupons";
import AdminMarkupEditor from "./pages/admin/AdminMarkupEditor";
import AdminProviderSync from "./pages/admin/AdminProviderSync";
import AdminActivityLog from "./pages/admin/AdminActivityLog";
import AdminSystemSettings from "./pages/admin/AdminSystemSettings";
import AdminRefunds from "./pages/admin/AdminRefunds";
import AdminManualOrder from "./pages/admin/AdminManualOrder";
import AdminRevenueExport from "./pages/admin/AdminRevenueExport";
import AdminMassNotification from "./pages/admin/AdminMassNotification";
import AdminAffiliates from "./pages/admin/AdminAffiliates";
import AdminCategories from "./pages/admin/AdminCategories";
import AdminGrowth from "./pages/admin/AdminGrowth";
import AdminThemeEditor from "./pages/admin/AdminThemeEditor";
import AdminLandingEditor from "./pages/admin/AdminLandingEditor";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <HelmetProvider>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>}>
              <Route path="services" element={<Services />} />
              <Route path="new-order" element={<NewOrder />} />
              <Route path="mass-order" element={<MassOrder />} />
              <Route path="orders" element={<Orders />} />
              <Route path="orders/:orderId" element={<OrderDetail />} />
              <Route path="analytics" element={<SpendingAnalytics />} />
              <Route path="account" element={<AccountManagement />} />
              <Route path="wallet" element={<WalletPage />} />
              <Route path="support" element={<Support />} />
              <Route path="tickets" element={<Tickets />} />
              <Route path="updates" element={<Updates />} />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="api" element={<ApiDocs />} />
              <Route path="affiliates" element={<Affiliates />} />
            </Route>
            <Route path="/admin" element={<ProtectedRoute><AdminRoute><AdminLayout /></AdminRoute></ProtectedRoute>}>
              <Route path="orders" element={<AdminOrders />} />
              <Route path="create-order" element={<AdminManualOrder />} />
              <Route path="users" element={<AdminUsers />} />
              <Route path="users/:userId" element={<AdminUserDetail />} />
              <Route path="services" element={<AdminServices />} />
              <Route path="markup" element={<AdminMarkupEditor />} />
              <Route path="coupons" element={<AdminCoupons />} />
              <Route path="tickets" element={<AdminTickets />} />
              <Route path="finance" element={<AdminFinance />} />
              <Route path="refunds" element={<AdminRefunds />} />
              <Route path="revenue" element={<AdminRevenueExport />} />
              <Route path="provider" element={<AdminProviderSync />} />
              <Route path="blog" element={<AdminBlog />} />
              <Route path="announcements" element={<AdminAnnouncements />} />
              <Route path="activity" element={<AdminActivityLog />} />
              <Route path="settings" element={<AdminSystemSettings />} />
              <Route path="mass-notify" element={<AdminMassNotification />} />
              <Route path="affiliates" element={<AdminAffiliates />} />
              <Route path="categories" element={<AdminCategories />} />
              <Route path="growth" element={<AdminGrowth />} />
              <Route path="theme" element={<AdminThemeEditor />} />
              <Route path="landing" element={<AdminLandingEditor />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
          <CookieConsent />
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
    </HelmetProvider>
  </QueryClientProvider>
);

export default App;
