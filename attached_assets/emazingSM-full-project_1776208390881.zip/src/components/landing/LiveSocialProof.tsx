import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Users, ShoppingCart, Layers } from "lucide-react";

interface Stats {
  totalOrders: number;
  activeUsers: number;
  totalServices: number;
}

export default function LiveSocialProof() {
  const [stats, setStats] = useState<Stats>({ totalOrders: 0, activeUsers: 0, totalServices: 0 });

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const [ordersRes, servicesRes] = await Promise.all([
        supabase.from("orders").select("id", { count: "exact", head: true }),
        supabase.from("services").select("id", { count: "exact", head: true }).eq("is_active", true),
      ]);
      if (cancelled) return;
      setStats({
        totalOrders: Math.max(ordersRes.count ?? 0, 12847), // floor for social proof
        activeUsers: Math.max(Math.floor((ordersRes.count ?? 0) / 3), 3200),
        totalServices: servicesRes.count ?? 450,
      });
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const items = [
    { icon: ShoppingCart, label: "Orders Delivered", value: stats.totalOrders.toLocaleString() },
    { icon: Users, label: "Active Users", value: stats.activeUsers.toLocaleString() },
    { icon: Layers, label: "Services Available", value: stats.totalServices.toLocaleString() },
  ];

  return (
    <div className="flex flex-wrap items-center justify-center gap-6 py-4">
      {items.map((item) => (
        <div key={item.label} className="flex items-center gap-2 text-sm">
          <item.icon className="w-4 h-4 text-primary" />
          <span className="font-heading font-bold text-foreground">{item.value}</span>
          <span className="text-muted-foreground text-xs">{item.label}</span>
        </div>
      ))}
    </div>
  );
}
