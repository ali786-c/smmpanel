

# Landing Page Premium Upgrade — Final Recommendations

## Issues Found

1. **Footer brand mismatch** — Line 419 says `SMM<span>Panel</span>` instead of `emazin<span>gSM</span>`. Critical brand inconsistency.

2. **Sections feel repetitive** — Every section uses the same `glass rounded-2xl p-6` card style with identical spacing. No visual rhythm or hierarchy differentiation between sections.

3. **No visual hero asset** — The hero is text-only. Premium SaaS pages always have a product screenshot, mockup, or illustration above the fold.

4. **Live Order Feed is a standalone section** — It sits alone between hero and features, feeling disconnected. Should be integrated into the hero area as a side widget or removed as a full-width section.

5. **Testimonials show only 3 on desktop** — 6 testimonials are defined but the 3-column grid shows all 6 crammed together. A carousel or showing top 3 with a "see more" would be cleaner.

6. **No section background alternation** — Every section has the same flat background. Premium pages alternate between subtle bg tints to create visual separation.

7. **Trustpilot banner is low-impact** — Currently a simple glass card. Could be elevated with the actual Trustpilot green brand color accent.

8. **No gradient or decorative elements** — The page lacks subtle background orbs, grid patterns, or radial gradients that premium dark-mode SaaS sites use (without hurting performance — pure CSS only).

9. **CTA section is undersized** — The final call-to-action could be more impactful with a larger gradient background and stronger visual hierarchy.

10. **How It Works lacks connectors** — The 4 steps sit as isolated cards. A connecting line or arrow between them would make the flow clearer.

11. **Blog preview cards have no images** — Even placeholder gradient blocks would make them feel more complete.

12. **No "as seen in" or client logo row** — A common premium trust signal missing entirely.

---

## Recommended Changes (Performance-Safe)

All changes use CSS-only techniques (no images, no blur, no heavy animations) to maintain 100% Lighthouse speed.

| # | Change | Impact |
|---|--------|--------|
| 1 | **Fix footer brand name** to `emazin<span>gSM</span>` | Bug fix |
| 2 | **Add CSS-only decorative orbs** to hero (radial gradients via `::before`/`::after`) | Premium feel |
| 3 | **Alternate section backgrounds** — odd sections get a subtle `bg-muted/30` tint | Visual rhythm |
| 4 | **Move LiveOrderFeed into the hero** as a floating side card on desktop, below stats on mobile | Reduces page length, more dynamic hero |
| 5 | **Add a connecting line/dots** between How It Works steps | Clearer flow |
| 6 | **Add gradient color strips** to blog preview cards as faux-image headers | More polished |
| 7 | **Limit testimonials to 3 visible** with the best ones, or use a 2-row staggered layout | Cleaner |
| 8 | **Enlarge CTA section** with full-width gradient bg instead of a card-in-container | More impactful |
| 9 | **Add a "Trusted by 3,200+ agencies" logo-style row** using CSS text placeholders (no images) | Social proof |
| 10 | **Strengthen nav** with a subtle bottom-border glow on scroll | Premium nav feel |

### What NOT to Change
- No blur/backdrop-filter (kills mobile perf)
- No lazy-loaded images in hero (LCP penalty)
- No client-side animations beyond CSS transitions already in use
- No new JS dependencies
- All existing SEO metadata, JSON-LD, and semantic HTML stays intact

### Technical Details
- All decorative elements use CSS `background`, `::before`/`::after` pseudo-elements, or Tailwind utilities — zero runtime cost
- Section alternation via `className` conditionals — no layout shifts
- Blog card gradient headers are `<div className="h-32 rounded-t-2xl gradient-primary opacity-80" />` — no images
- Step connectors use a CSS border/dashed line between items via `relative`/`absolute` positioning

